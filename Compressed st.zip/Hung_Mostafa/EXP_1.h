/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_COMMANDBUTTON              2       /* control type: command, callback function: Bye */
#define  PANEL_COMMANDBUTTON_2            3       /* control type: command, callback function: subtract_st */
#define  PANEL_NUMERICGAUGE               4       /* control type: scale, callback function: nonsense_gauge */
#define  PANEL_DISPLAY                    5       /* control type: numeric, callback function: display */
#define  PANEL_COMMANDBUTTON_3            6       /* control type: command, callback function: grab_st */
#define  PANEL_COMMANDBUTTON_4            7       /* control type: command, callback function: Plot_st */
#define  PANEL_GRAPH_2                    8       /* control type: graph, callback function: (none) */
#define  PANEL_COMMANDBUTTON_5            9       /* control type: command, callback function: normalize_st */
#define  PANEL_COMMANDBUTTON_6            10      /* control type: command, callback function: centroid_of_st */
#define  PANEL_NUMERIC                    11      /* control type: numeric, callback function: (none) */
#define  PANEL_COMMANDBUTTON_7            12      /* control type: command, callback function: save_st */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK Bye(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK centroid_of_st(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK display(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK grab_st(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK nonsense_gauge(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK normalize_st(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Plot_st(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK save_st(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK subtract_st(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif