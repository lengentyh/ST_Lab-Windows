#include <advanlys.h>
#include <NIDAQmx.h>
#include <userint.h>
#include "exp_2_source.h"
#include <formatio.h>
#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
static float64 bst_data[100000];
static float64 bst_data_init[10000];
static double st_data[100000];
static double saved_array[100000];
static int32 st_num_read;
static TaskHandle data_st;
static int panelHandle;
int static data_read[820];
int static channel_st;
static double input_time;
static double input_sampling_freq;
static double time_axis[100000];
static double freq_axis[100000];
static int it;
static int num_scan;
static int32 num_scan_read;

int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "exp_2_source.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}


int CVICALLBACK quit_st (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			QuitUserInterface (0);
			break;
	}
	return 0;
}

int CVICALLBACK acquire_st (int panel, int control, int event,
							void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			// get value from the GUI
			GetCtrlVal (panelHandle, PANEL_NUMERIC, &input_time);
			GetCtrlVal (panelHandle, PANEL_NUMERIC_2, &input_sampling_freq);
			
			
			// read data from st_card
			DAQmxCreateTask ("YH-MA-task", &data_st);
			DAQmxCreateAIVoltageChan (data_st, "Dev1/ai0", "YH-MA-channel", DAQmx_Val_Diff, -10.0, 10.0, DAQmx_Val_Volts, "");
			num_scan = input_time*input_sampling_freq;
			DAQmxCfgSampClkTiming (data_st, "OnboardClock", input_sampling_freq, DAQmx_Val_Rising, DAQmx_Val_ContSamps,num_scan);
			DAQmxStartTask (data_st);
			DAQmxReadAnalogF64 (data_st, num_scan, 10*num_scan, DAQmx_Val_GroupByChannel, bst_data, num_scan, &num_scan_read, 0);
			for(it=0;it<num_scan;it++){
				time_axis[it] = it*(1/input_sampling_freq);
			};
			
			// Plot time
			PlotXY (panelHandle, PANEL_GRAPH_3, time_axis, bst_data, num_scan, VAL_DOUBLE, VAL_DOUBLE, VAL_FAT_LINE, VAL_SOLID_DIAMOND, VAL_SOLID, 1, VAL_RED);
			
			// Plot Freq
			for(it=0;it<num_scan;it++){
				bst_data_init[it] = bst_data[it];
			};
			Spectrum (bst_data, num_scan);
			for(it=0;it<num_scan;it++){
				freq_axis[it] = it*(1/input_time);
			};
			PlotXY (panelHandle, PANEL_GRAPH_2, freq_axis, bst_data, num_scan, VAL_DOUBLE, VAL_DOUBLE,
					VAL_THIN_LINE, VAL_EMPTY_DIAMOND, VAL_DOT, 1, VAL_RED);
			
			break;
	}
	return 0;
}


int CVICALLBACK save_st (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			for(it=0;it<num_scan;it++){
			saved_array[it] = bst_data_init[it];
			} 
			for(it=0;it<num_scan;it++){
			saved_array[it+num_scan+1] = bst_data[it];
			}
			ArrayToFile ("C:\\Users\\Public\\Hung_Mostafa 2\\2nd_st.txt", saved_array, VAL_DOUBLE, 2*num_scan, 2, VAL_GROUPS_TOGETHER, VAL_GROUPS_AS_COLUMNS,
             VAL_CONST_WIDTH, 10, VAL_ASCII, VAL_TRUNCATE);
			break;
	}
	return 0;
}

int CVICALLBACK save_ax_st (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			for(it=0;it<num_scan;it++){
			saved_array[it] = time_axis[it];
			} 
			for(it=0;it<num_scan;it++){
			saved_array[it+num_scan+1] = freq_axis[it];
			}
			ArrayToFile ("C:\\Users\\Public\\Hung_Mostafa 2\\2nd_ax_st.txt", saved_array, VAL_DOUBLE, 2*num_scan, 2, VAL_GROUPS_TOGETHER, VAL_GROUPS_AS_COLUMNS,
             VAL_CONST_WIDTH, 10, VAL_ASCII, VAL_TRUNCATE);
			break;
	}
	return 0;
}
