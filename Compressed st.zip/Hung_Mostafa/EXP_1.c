#include <formatio.h>
#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include "EXP_1.h"
static double dataxy[1000];
static int file_opened;
static int read=1;
static char data[1000];
static char pn[300];
static double x;
static int num_loop=0;
static double x_axis[500];
static double y_axis[500];
static int j;
static int panelHandle;
static double area=0;
static double centroid_area=0;
static int centroid;
static double saved_array[500];

int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "EXP_1.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK Bye (int panel, int control, int event,
					 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			QuitUserInterface (0);
			break;
	}
	return 0;
}


int CVICALLBACK nonsense_gauge (int panel, int control, int event,
								void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			break;
	}
	return 0;
}

int CVICALLBACK display (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK grab_st (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			FileSelectPopup ("C:\\Users\\mohamed.al\\Downloads", "*.txt", "*.txt", "1d",
                     VAL_LOAD_BUTTON, 0, 0, 0, 0, pn);
			file_opened = OpenFile (pn, VAL_READ_ONLY, VAL_OPEN_AS_IS, VAL_ASCII);
			while(read!=0){
				read = ReadFile (file_opened, data, 1);
				if(data[0]=='\t'){
					num_loop = num_loop + 1;
				}
			}
			// printf("%i",num_loop);
			FileToArray ("c:\\Users\\mohamed.al\\Downloads\\1d.txt", dataxy, VAL_DOUBLE, num_loop*2, 1,
             VAL_GROUPS_TOGETHER, VAL_GROUPS_AS_COLUMNS, VAL_ASCII);
			// printf("%.6f %.6f",dataxy[0],dataxy[100]);
			
			for(j=0;j<2*num_loop;j++){
				if (j%2 == 0){
					x_axis[j/2] = dataxy[j];
					//printf("%.9f \n",x_axis[j/2]);
				}
				else{
					y_axis[(j-1)/2] = dataxy[j];
					//printf("%.9f \n",y_axis[(j-1)/2]);
				}
			}
			break;
	}
	return 0;
}

int CVICALLBACK Plot_st (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			PlotXY (panelHandle, PANEL_GRAPH_2, x_axis, y_axis, num_loop, VAL_DOUBLE, VAL_DOUBLE,
					VAL_THIN_LINE, VAL_EMPTY_DIAMOND, VAL_DOT, 1, VAL_RED);
			break;
	}
	return 0;
}


int CVICALLBACK subtract_st (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (panelHandle, PANEL_NUMERICGAUGE, &x);
			for(j=0;j<2*num_loop;j++){
				y_axis[j] = y_axis[j] - x;
			}
			// x=pow(x,x+1);
			// SetCtrlVal (panelHandle, PANEL_DISPLAY, x);
			break;
	}
	return 0;
}

int CVICALLBACK normalize_st (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			for(j=0;j<num_loop+1;j++){
				area = area + y_axis[j];
			}
			for(j=0;j<num_loop+1;j++){
			y_axis[j] = (1/area)*y_axis[j];
			}
			break;
	}
	return 0;
}

int CVICALLBACK centroid_of_st (int panel, int control, int event,
								void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			for(j=0;j<num_loop+1;j++){
				centroid_area = centroid_area + y_axis[j];
				if (centroid_area>0.5){
					centroid = j;
					// printf("%i",j);
					SetCtrlVal (panelHandle,PANEL_NUMERIC, centroid);
					break;
				}
			}
			break;
	}
	return 0;
}

int CVICALLBACK save_st (int panel, int control, int event,
						 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			for(j=0;j<num_loop+1;j++){
			saved_array[j] = x_axis[j];
			} 
			for(j=0;j<num_loop+1;j++){
			saved_array[j+num_loop+1] = y_axis[j];
			}
			ArrayToFile ("c:\\Users\\mohamed.al\\Downloads\\1d_st.txt", saved_array, VAL_DOUBLE, 2*num_loop, 2, VAL_GROUPS_TOGETHER, VAL_GROUPS_AS_COLUMNS,
             VAL_CONST_WIDTH, 10, VAL_ASCII, VAL_TRUNCATE);
			break;
	}
	return 0;
}
